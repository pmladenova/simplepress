=== SimplePress ===
Stable tag: 1.0.0
SimplePress ClassicPress theme, Copyright (C) 2013 Petya Mladenova
SimplePress ClassicPress theme is licensed under the GNU GPL v3.0

== Description ==
A Simple ClassicPress Theme

== Installation ==
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

= Does this theme support any plugins? =
1. Footer Credits / €10
This extension lets you set your own custom credits in the footer.
2. Combine CSS files / Free
Combined CSS files for better page speed.
3. Combine JS files / Free
Combined JS files for better page speed.

More info -> https://inter-reklama.com/simplepress-theme.html

= Recommended plugin for this theme: WP-PostViews =
Link -> https://wordpress.org/plugins/wp-postviews/
You need to install and activate the plugin.
The code is implemented and will only be active if the plugin is activated.

= How To Get Download Function =
Source -> https://remicorson.com/easy-download-media-counter-free/
Shortcodes:
[dwn id="xxx"]Download Media Now![/dwn] 
[dwn_show id="xxx"]

== Changelog ==

= 1.0.0 - May 31 2020 =
* Initial release

== Credits ==
* Underscores (_s) - Base Theme
URL: https://underscores.me/
License: GNU GPL
Copyright: Automattic, automattic.com
License URI: LICENSE

== FOOTER LINK ==
You can remove the footer link if you like but we would appreciate your support for our work by retaining it.